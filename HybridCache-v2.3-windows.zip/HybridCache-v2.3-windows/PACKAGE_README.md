# HybridCache Services v2.3

Cross-platform caching services with encryption support.

## Quick Installation

### Windows
```cmd
install.bat
```

### Linux/macOS
```bash
chmod +x install.sh
./install.sh
```

## Manual Installation
```bash
python install.py --install-dir ./HybridCache
```

## Services Included

- **Gov Service**: GOST encryption, integrity checks, FSTEC compliance
- **Commercial Service**: AES-256 encryption, standard compliance  
- **Fast Service**: Optimized for maximum speed (recommended)

## Features

- Cross-platform (Windows, Linux, macOS)
- Multiple encryption modes (AES-256, GOST)
- HTTP API with FastAPI
- Performance benchmarking
- Docker support
- Configurable cache policies

## Usage

After installation, navigate to the HybridCache directory and run:

- `start_fast.bat` / `./start_fast.sh` - Start optimized service
- `start_gov.bat` / `./start_gov.sh` - Start government service
- `run_benchmark.bat` / `./run_benchmark.sh` - Run performance tests
- `install_docker.bat` / `./install_docker.sh` - Start with Docker

## Configuration

Edit `.env` file to configure:
- Cache directory
- Source directory  
- Encryption settings
- Cache size limits

## API Endpoints

- `GET /api/cache/{filename}` - Get cached file
- `POST /api/preload` - Preload files to cache

## Performance

Optimized fast service shows 4.3% improvement over direct file access
on local SSD storage.

## Requirements

- Python 3.8+
- 100MB free space
- Optional: Docker for containerized deployment

## Support

See README.md for detailed documentation.
