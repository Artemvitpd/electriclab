@echo off
echo HybridCache Services - Quick Start
echo ================================
echo.
echo Installing HybridCache...
python install.py --install-dir ./HybridCache
echo.
echo Installation complete! 
echo.
echo To start services:
echo   - Fast service: cd HybridCache && start_fast.bat
echo   - Gov service: cd HybridCache && start_gov.bat  
echo   - Benchmark: cd HybridCache && run_benchmark.bat
echo   - Docker: cd HybridCache && install_docker.bat
echo.
pause
